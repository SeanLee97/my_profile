# Homework Description

- task1: 将 corpus 目录下的 `yttlj.txt` 分词，用空格分隔每个词输出到新文件 `yttlj.seg.txt` 中

- task2: 去除 corpus 下指定的停用词 `stopwords.txt` 后统计词频，生成词频字典，将得到的词典按词频逆序输出到文件 `vocab.txt` 中，`vocab.txt` 的格式为：
  
  词 \t 词id \t 词频

- task3: 使用 jieba 提供的 tf-idf 关键词提取方式提取前十个（top 10）关键词，且这些关键词是去除 `stopwords.txt` 停用词后的, 
  且只允许 'ns', 'n', 'vn', 'nr' 四个词性，将结果输出到 `keywords_tfidf.txt`

- task4: 使用 jieba 提供的 textrank 关键词提取方式提取前十个（top 10）关键词，且这些关键词是去除 `stopwords.txt` 停用词后的, 
  且只允许 'ns', 'n', 'vn', 'nr' 四个词性，将结果输出到 `keywords_tfidf.txt`

- task5: 附加题：
  自己实现 tf-idf 算法提取关键词


具体的输出样例可以参照 `result` 目录下的输出，作业完成时会公布全部代码:>
