# -*- coding: utf-8 -*-

"""Description:
   将 corpus 目录下的 `yttlj.txt` 分词，用空格分隔每个词输出到新文件 `yttlj.seg.txt` 中
"""

import jieba

def main():
    corpus_file = '../../corpus/yttlj.txt'
    output_file = './yttlj.seg.txt'

    with open(corpus_file, 'r') as rf, open(output_file, 'w') as wf:
        for line in rf:
            line = line.strip()
            words = jieba.lcut(line)
            out_line = ' '.join(words)
            wf.writelines(out_line + '\n')


if __name__ == '__main__':
    print("Start to process...")

    main()

    print("Done with processing !") 
