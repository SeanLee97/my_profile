# -*- coding: utf-8 -*-

"""Description:
   去除 corpus 下指定的停用词 `stopwords.txt` 后统计词频，统计词频，生成词频字典，将得到的词典按词频逆序输出到文件 `vocab.txt` 中，`vocab.txt` 的格式为：

     词 \t 词id \t 词频

"""

import jieba
from collections import defaultdict

def main():
    corpus_file = '../../corpus/yttlj.txt'
    output_file = './vocab.txt'

    stopwords_file = '../../corpus/stopwords.txt'

    # 加载停用词
    stopwords = set()
    with open(stopwords_file, 'r') as rf:
        for line in rf:
            stopwords.add(line.strip())

    # 涉及到统计操作一般用 哈希表(python 中的字典) 来记录

    word2idx = {}
    word2freq = defaultdict(int)

    with open(corpus_file, 'r') as rf, open(output_file, 'w') as wf:
        # 读取语料
        for line in rf:
            line = line.strip()
            for word in jieba.lcut(line):
                # 过滤掉停用词
                if word in stopwords:
                    continue

                if word not in word2idx:
                    word2idx[word] = len(word2idx)
                word2freq[word] += 1
            
        # 逆序排列
        word2freq = dict(sorted(word2freq.items(), key=lambda x: -x[1]))

        # 定义输出格式
        out_format = "{}\t{}\t{}\n"

        # 输出
        for word, freq in word2freq.items():
            wf.writelines(out_format.format(word, word2idx[word], freq))

if __name__ == '__main__':
    print("Start to process...")

    main()

    print("Done with processing !") 
