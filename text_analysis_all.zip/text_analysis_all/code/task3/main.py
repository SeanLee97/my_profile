# -*- coding: utf-8 -*-

"""Description:
   使用 jieba 提供的 tf-idf 关键词提取方式提取前十个（top 10）关键词，且这些关键词是去除 `stopwords.txt` 停用词后的, 将结果输出到 `keywords_tfidf.txt`

"""

import jieba
import jieba.analyse

# 设置停用词
jieba.analyse.set_stop_words('../../corpus/stopwords.txt')

def main():
    corpus_file = '../../corpus/yttlj.txt'
    output_file = './keywords_tfidf.txt'
    topK = 10

    with open(corpus_file, 'r') as rf, open(output_file, 'w') as wf:
        content = rf.read()
        keywords = jieba.analyse.extract_tags(content, topK=topK, allowPOS=('ns', 'n', 'vn', 'nr'))

        wf.writelines('\n'.join(keywords))

if __name__ == '__main__':
    print("Start to process...")

    main()

    print("Done with processing !") 
