# -*- coding: utf-8 -*-

"""Description:
   自己实现 tf-idf 算法提取关键词
"""

import jieba
import jieba.posseg as pseg
import numpy as np

def tfidf_keywords(file_path, stopwords=[], topK=10, allowPOS=('n', 'nr', 'ns', 'vn')):
    docs = []
    
    word2idx = {}

    with open(file_path, 'r') as rf:
        for line in rf:
            if len(line.strip()) < 5:
                continue 
            words = []
            for word, tag in pseg.cut(line.strip()):
                if word not in stopwords and tag in allowPOS:
                    words.append(word)
                    if word not in word2idx:
                        word2idx[word] = len(word2idx)
            if len(words) > 0: 
                docs.append(words)

    # calc tfidf using numpy
    v_s = len(word2idx) # vocabs size
    d_s = len(docs)     # docs size

    tf = np.zeros([d_s, v_s])
    df = np.ones([1, v_s])
    for docidx, doc in enumerate(docs):
        for word in doc:
            tf[docidx, word2idx[word]] += 1
            df[0, word2idx[word]] += 1

        # 归一化
        tf[docidx] /= np.max(tf[docidx])

    idf = np.log(float(d_s)) - np.log(df)
    tfidf = np.multiply(tf, idf)

    tfidf_mean = np.mean(tfidf, axis=0)
    word_score = list(zip(word2idx.keys(), tfidf_mean))
    word_score_sort = sorted(word_score, key=lambda x: -x[1])
    return word_score_sort[:topK]

def main():
    corpus_file = '../../corpus/yttlj.txt'
    output_file = './keywords_tfidf.txt'
    topK = 10

    keywords = tfidf_keywords(corpus_file)

    print(keywords)

    
if __name__ == '__main__':
    print("Start to process...")

    main()

    print("Done with processing !") 
